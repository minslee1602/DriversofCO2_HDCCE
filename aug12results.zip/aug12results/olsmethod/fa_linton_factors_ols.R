# Factor-augmented panel OLS in R — factors built with LINTON's HD-CCE steps.
# system(paste("chmod u+w", shQuote(getwd())))
# system(paste("touch", shQuote(file.path(getwd(), "test.txt"))))  
# Settings
TRUNC       <- 0.01     # Linton's tau for the K_hat rule
NFACTORS    <- 3        # force 3 factors (set to NULL to use the data-driven rule)
STANDARDIZE <- TRUE     # standardize regressors before extracting factors
INCLUDE_YBAR <- TRUE    # add cross-sectional avg of the DV (ybar_t) as a regressor

# if bootstrap needed for generated regressors
REPS        <- 500      
RUN_BOOT_POOLED <- TRUE 
RUN_BOOT_INT    <- TRUE
LINTON_SRC  <- "hdcce_estimator.R"   # path to Linton's estimator file
DATA_XLSX   <- "Cabon_Emm_disaggregate.xlsx"
SEED        <- 12345

suppressMessages({
  library(readxl); library(dplyr); library(fixest)
})
if (file.exists(LINTON_SRC)) source(LINTON_SRC)  

SCRIPT_DIR <- tryCatch(
  this.path::here(),
  error = function(e) tryCatch(
    dirname(rstudioapi::getActiveDocumentContext()$path),
    error = function(e2) stop("Set SCRIPT_DIR manually — could not detect the script location.")
  )
)

# load data
df <- read_excel(DATA_XLSX)
names(df) <- gsub("\\.", "_", names(df))   # Country.Code -> Country_Code, etc.

# country id
df$country_id <- as.integer(factor(df$Country_Code))

yr_raw <- df$Year
df$year <- {
  if (inherits(yr_raw, c("Date","POSIXct"))) {
    as.integer(format(yr_raw, "%Y"))
  } else if (is.numeric(yr_raw) && max(yr_raw) > 3000) {
    as.integer(format(as.Date(yr_raw, origin = "1960-01-01"), "%Y"))
  } else if (is.character(yr_raw)) {
    as.integer(substr(yr_raw, 1, 4))
  } else {
    as.integer(yr_raw)
  }
}

# carbon-tax status
df$Carbon_Tax <- as.numeric(df$Carbon_Tax)
df <- df %>% group_by(country_id) %>%
  mutate(has_ctax = max(Carbon_Tax, na.rm = TRUE)) %>% ungroup()

# drivers as list
drivers <- c(
  "gdp_pc","gdpsq_pc",
  "coal_production_pc","oil_production_pc","gas_production_pc",
  "solar_production_pc","wind_production_pc","hydro_production_pc",
  "other_renewables_production_pc",
  "coal_consumption_pc","oil_consumption_pc","gas_consumption_pc",
  "solar_consumption_pc","wind_consumption_pc","hydro_consumption_pc",
  "other_renewable_consumption_pc",
  "imf_fi_access","imf_fi_depth","imf_fi_efficiency",
  "imf_fm_access","imf_fm_depth","imf_fm_efficiency"
)

# standardize
Zdf <- as.data.frame(scale(df[drivers]))      # egen std
names(Zdf) <- paste0("z_", drivers)
df <- bind_cols(df, Zdf)
Zvars <- names(Zdf)
FVARS <- if (STANDARDIZE) Zvars else drivers   

# Linton steps 1-3 (CSA, Factors with second moment matrix, Project out)
linton_factors <- function(Zmat, year, TRUNC = 0.01, NFACTORS = NULL) {
  yrs   <- sort(unique(year))
  obs_T <- length(yrs)
  
  # Step 1: cross-sectional averages -> X_bar (T x p)
  X_bar <- t(vapply(yrs, function(yy) colMeans(Zmat[year == yy, , drop = FALSE]),
                    numeric(ncol(Zmat))))
  # uncentred second-moment matrix + symmetric eigendecomposition
  Cov_X_bar       <- 1/obs_T * t(X_bar) %*% X_bar
  Cov_X_bar_eigen <- eigen(Cov_X_bar, symmetric = TRUE)
  
  # Step 2: normalize eigenvalues by the largest; count those above TRUNC
  eigen_values <- Cov_X_bar_eigen$values / Cov_X_bar_eigen$values[1]
  K_auto <- sum(TRUNC < eigen_values)
  K_use  <- if (!is.null(NFACTORS)) NFACTORS else K_auto
  
  # Step 3: factors = X_bar projected onto the leading K eigenvectors
  W_hat <- X_bar %*% Cov_X_bar_eigen$vectors[, 1:K_use, drop = FALSE]
  colnames(W_hat) <- paste0("f", seq_len(K_use))
  
  list(What = data.frame(year = yrs, W_hat),
       K_use = K_use, K_auto = K_auto, eigen_norm = eigen_values)
}

fac <- linton_factors(as.matrix(df[FVARS]), df$year, TRUNC, NFACTORS)
K   <- fac$K_use
fvars <- paste0("f", seq_len(K))

# attach the factors to every country-year by year
df <- left_join(df, fac$What, by = "year")

# ybar_t : cross-sectional average of the DV, by year.
# Helper so the bootstrap can recompute it on each drawn panel.
add_ybar <- function(d) {
  yb <- tapply(d$carbon_emissions_pc, d$year, mean)
  d$ybar <- as.numeric(yb[as.character(d$year)])
  d
}
augvars <- fvars                                  # augmentation controls
if (INCLUDE_YBAR) { df <- add_ybar(df); augvars <- c(fvars, "ybar") }

cat("-------------------------------------------------------------\n")
cat("Factors used (K):         ", fac$K_use,  "\n")
cat("Data-driven K_hat (rule): ", fac$K_auto, "   [TRUNC =", TRUNC, "]\n")
if (fac$K_use != fac$K_auto)
  cat("NOTE: forced K differs from the truncation rule's K_hat.\n")
cat("Normalized eigenvalues:\n"); print(round(fac$eigen_norm, 6))
cat("-------------------------------------------------------------\n")

# Factor-augmented FE OLS (factors INCLUDED as regressors) -----
# fixest: country FE via | country_id ; clustered SEs via cluster=~country_id
rhs   <- paste(c(Zvars, augvars), collapse = " + ")
f_main <- as.formula(paste("carbon_emissions_pc ~", rhs, "| country_id"))

m_pooled <- feols(f_main, data = df,                      cluster = ~country_id)
m_ctax   <- feols(f_main, data = subset(df, has_ctax==1), cluster = ~country_id)
m_noctax <- feols(f_main, data = subset(df, has_ctax==0), cluster = ~country_id)

# interacted: group-specific DRIVER slopes only; SHARED controls are the
# factors ONLY.  ybar remains in the pooled and split-sample specifications above.
aug_int <- fvars                                  # interacted-model shared controls
rhs_int <- paste(sprintf("i(has_ctax, %s)", Zvars), collapse = " + ")
f_int   <- as.formula(paste("carbon_emissions_pc ~", paste(c(Zvars, aug_int), collapse=" + "),
                            "+", rhs_int, "| country_id"))
m_inter <- feols(f_int, data = df, cluster = ~country_id)

cat("\n===== Pooled =====\n");             print(summary(m_pooled))
cat("\n===== Carbon-tax =====\n");         print(summary(m_ctax))
cat("\n===== Non-carbon-tax =====\n");     print(summary(m_noctax))
cat("\n===== Interacted =====\n");         print(summary(m_inter))

# export a side-by-side table (naive clustered SEs)
etable(m_pooled, m_ctax, m_noctax,
       headers = c("Pooled","Carbon-tax","Non-tax"),
       file = "fa_linton_ols_results_R.txt", replace = TRUE)

# helper: build a resampled panel (countries drawn WITH replacement, each
# draw gets a distinct newid so duplicated countries don't collapse the FE),
# re-estimate the Linton factors on that resample, return the panel.
resample_panel <- function(df, K) {
  ids  <- unique(df$country_id)
  draw <- sample(ids, length(ids), replace = TRUE)
  newp <- do.call(rbind, Map(function(id, j) {
    s <- df[df$country_id == id, ]; s$newid <- j; s
  }, draw, seq_along(draw)))
  fac_b <- linton_factors(as.matrix(newp[FVARS]), newp$year, TRUNC, NFACTORS = K)
  newp[fvars] <- NULL
  newp <- left_join(newp, fac_b$What, by = "year")
  if (INCLUDE_YBAR) newp <- add_ybar(newp)   # recompute ybar on the resample
  newp
}

# Pooled generated-regressor bootstrap 
if (RUN_BOOT_POOLED) {
  set.seed(SEED)
  b0 <- coef(feols(f_main, data = df))          # point estimates (plain FE)
  keep <- Zvars                                
  B <- matrix(NA_real_, nrow = REPS, ncol = length(keep), dimnames = list(NULL, keep))
  f_boot <- as.formula(paste("carbon_emissions_pc ~", rhs, "| newid"))
  ok <- 0
  for (r in 1:REPS) {
    newp <- resample_panel(df, K)
    fit  <- tryCatch(feols(f_boot, data = newp, notes = FALSE), error = function(e) NULL)
    if (is.null(fit)) next
    cf <- coef(fit); B[r, ] <- cf[keep]; ok <- ok + 1
  }
  bse  <- apply(B, 2, sd, na.rm = TRUE)
  bhat <- b0[keep]
  tval <- bhat / bse
  pval <- 2 * (1 - pnorm(abs(tval)))
  pooled_boot <- data.frame(driver = keep, b = bhat, bse = bse, t = tval, p = pval)
  cat("\n--- POOLED bootstrap (", ok, "of", REPS, "draws) ---\n")
  print(pooled_boot, row.names = FALSE, digits = 4)
  write.csv(pooled_boot, "boot_pooled_R.csv", row.names = FALSE)
}

# Interacted-model bootstrap 
if (RUN_BOOT_INT) {
  set.seed(SEED)
  m0   <- feols(f_int, data = df)
  keep <- names(coef(m0))                        # main effects + interactions
  b0i  <- coef(m0)
  B <- matrix(NA_real_, nrow = REPS, ncol = length(keep), dimnames = list(NULL, keep))
  f_boot_int <- as.formula(paste("carbon_emissions_pc ~", paste(c(Zvars, aug_int), collapse=" + "),
                                 "+", rhs_int, "| newid"))
  ok <- 0
  for (r in 1:REPS) {
    newp <- resample_panel(df, K)
    fit  <- tryCatch(feols(f_boot_int, data = newp, notes = FALSE), error = function(e) NULL)
    if (is.null(fit)) next
    cf <- coef(fit); B[r, names(cf)] <- cf; ok <- ok + 1
  }
  bse  <- apply(B, 2, sd, na.rm = TRUE)
  tval <- b0i / bse
  pval <- 2 * (1 - pnorm(abs(tval)))
  is_int <- grepl("has_ctax", keep)
  int_boot <- data.frame(term = keep, b = b0i, bse = bse, t = tval, p = pval,
                         kind = ifelse(is_int, "difference(tax-nontax)", "nontax_slope"))
  cat("\n--- INTERACTED bootstrap (", ok, "of", REPS, "draws) ---\n")
  cat("\nMAIN EFFECTS (non-carbon-tax slopes):\n")
  print(subset(int_boot, !is_int, c(term,b,bse,t,p)), row.names = FALSE, digits = 4)
  cat("\nINTERACTIONS (carbon-tax minus non-tax):\n")
  print(subset(int_boot,  is_int, c(term,b,bse,t,p)), row.names = FALSE, digits = 4)
  write.csv(int_boot, "boot_interacted_R.csv", row.names = FALSE)
}

