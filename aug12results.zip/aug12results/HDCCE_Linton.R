# Desparsified HD-CCE inference for the carbon-emissions panel.

# install.packages(c("readxl","glmnet","this.path"))
# =============================================================================

PROJ_DIR <- tryCatch(this.path::here(), error = function(e) getwd())
setwd(PROJ_DIR)
library(readxl)
library(glmnet)

# Linton's estimator + inference functions
source("hdcce_estimator.R")
source("hdcce_inference.R")

########################### 0. Settings ########################################

K_FACTORS   <- 3            
STANDARDIZE <- FALSE        
LAMBDA_RULE <- "lambda.min" 
TRACE_J     <- 1            # which driver to trace by hand in section 8

# To drop renewable consumption
DROP_RENEWABLE_CONSUMPTION <- FALSE

########################### 1. Data ############################################

data  <- as.data.frame(read_excel("Cabon_Emm_disaggregate.xlsx"))
data  <- data[order(data$Country.Code, data$Year), ]      # unit-by-unit
n_dim <- 42
T_dim <- 30

stopifnot(nrow(data) == n_dim * T_dim)   # 42 * 30 = 1260; catches a dropped unit

Y <- as.numeric(data$carbon_emissions_pc)                 # dependent variable

redundant <- c("fossil_fuel_production_pc", "fossil_fuel_consumption_pc",
               "renewables_production_pc",  "renewables_consumption_pc",
               "hydro_consumption", "solar_consumption",
               "wind_consumption",  "other_renewable_consumption")

imf_aggregates <- c("imf_fd_index", "imf_fi_index", "imf_fm_index")

renew_consumption <- c("hydro_consumption_pc", "solar_consumption_pc",
                       "wind_consumption_pc",  "other_renewable_consumption_pc")
if (DROP_RENEWABLE_CONSUMPTION) redundant <- c(redundant, renew_consumption)

drop_cols <- c("Country.Name", "Country.Code", "OECD", "EU", "G7", "BRICS",
               "Carbon.Tax", "Year", "carbon_emissions_pc",
               "fd_index",                     # non-IMF FD aggregate
               imf_aggregates,
               redundant)

missing_drop <- setdiff(drop_cols, colnames(data))
if (length(missing_drop))
  stop("drop_cols entries not found in the workbook: ",
       paste(missing_drop, collapse = ", "),
       "\n  -> nothing was removed for these; fix the names before proceeding.")

X            <- scale(as.matrix(data[, setdiff(colnames(data), drop_cols)]))
p            <- ncol(X)
driver_names <- colnames(X)

stopifnot(p == if (DROP_RENEWABLE_CONSUMPTION) 18 else 22)
cat("panel:", n_dim, "units x", T_dim, "periods,", p, "drivers\n")


########################### 2. Structural groups ###############################

country  <- data$Country.Code[seq(1, n_dim * T_dim, by = T_dim)]
has_ctax <- tapply(as.numeric(data$Carbon.Tax), data$Country.Code, max)[country] == 1
group    <- ifelse(has_ctax, "carbon-tax", "no-carbon-tax")
row_grp  <- rep(group, each = T_dim)

rows_ct  <- which(row_grp == "carbon-tax");    ng_ct  <- sum(group == "carbon-tax")
rows_nct <- which(row_grp == "no-carbon-tax"); ng_nct <- sum(group == "no-carbon-tax")

stopifnot(ng_ct + ng_nct == n_dim)

########################### 3. Shared helpers ##################################

# Process for projecting csa factor proxies
csa_projection <- function(x, obs_N, obs_T, K = K_FACTORS, alpha = 0.01) {
  x  <- as.matrix(x)
  pp <- ncol(x)
  
  # seq(t, obs_N * obs_T, by = obs_T)
  X_bar <- matrix(NA_real_, obs_T, pp)
  for (t in seq_len(obs_T))
    X_bar[t, ] <- colMeans(x[seq(t, obs_N * obs_T, by = obs_T), , drop = FALSE])
  
  eig <- eigen(crossprod(X_bar) / obs_T, symmetric = TRUE)
  evn <- eig$values / eig$values[1]
  U   <- eig$vectors[, seq_len(K), drop = FALSE]
  W   <- X_bar %*% U
  Pi  <- diag(obs_T) - W %*% solve(crossprod(W)) %*% t(W)
  
  list(X_bar = X_bar, eigenvalues = evn, K = K,
       K_suggested = sum(evn > alpha),                
       U = U, W = W, Pi = Pi)
}

# Apply the projector within each unit's own block
defactor <- function(M, Pi, obs_N, obs_T) {
  M   <- as.matrix(M)
  out <- matrix(NA_real_, nrow(M), ncol(M))
  for (i in seq_len(obs_N)) {
    idx <- ((i - 1) * obs_T + 1):(i * obs_T)
    out[idx, ] <- Pi %*% M[idx, , drop = FALSE]
  }
  out
}

# Fit lasso
hdcce_stages <- function(x, y, obs_N, obs_T, K = K_FACTORS) {
  x  <- as.matrix(x)
  st <- list(p = ncol(x), K = K, obs_N = obs_N, obs_T = obs_T,
             driver = colnames(x))
  
  # CSA -> Factor proxies -> Projector
  pr <- csa_projection(x, obs_N, obs_T, K)
  st$proj  <- pr
  st$Xbar  <- pr$X_bar
  st$evn   <- pr$eigenvalues
  st$W     <- pr$W
  st$Pi    <- pr$Pi
  st$xt    <- defactor(x, pr$Pi, obs_N, obs_T)
  st$yt    <- as.numeric(defactor(matrix(y, ncol = 1), pr$Pi, obs_N, obs_T))
  st$var_kept <- apply(st$xt, 2, var) / apply(x, 2, var)
  
  # Shrinkage
  st$foldid <- rep(seq_len(obs_N), each = obs_T)        # leave-one-unit-out
  st$cv     <- cv.glmnet(st$xt, st$yt, foldid = st$foldid, alpha = 1,
                         intercept = FALSE, standardize = STANDARDIZE)
  st$lambda <- st$cv[[LAMBDA_RULE]]
  st$beta   <- as.numeric(coef(st$cv, s = st$lambda))[-1]
  names(st$beta) <- colnames(x)
  st$s <- sum(st$beta != 0)
  
  st
}

########################### 4. Desparsification ################################

# Desparsify EVERY COEFFICIENT of a given (x, y) panel via Linton's routine.
despar_all <- function(x, y, obs_N, obs_T, HAC = HAC_LAG, NFACTORS = K_FACTORS) {
  x  <- as.matrix(x)
  pp <- ncol(x)
  foldid <- rep(seq_len(obs_N), each = obs_T)
  o <- data.frame(driver = colnames(x), coef = NA_real_, se = NA_real_,
                  t = NA_real_, pval = NA_real_, lo = NA_real_, hi = NA_real_,
                  stringsAsFactors = FALSE)
  for (j in seq_len(pp)) {
    a <- list(data = list(x = x, y = y), obs_N = obs_N, obs_T = obs_T,
              foldid = foldid, COEF_INDEX_VEC = j, HAC = HAC)
    if (!is.null(NFACTORS)) a$NFACTORS <- NFACTORS
    r  <- do.call(hdcce_inference, a)
    
    b  <- r$coef_despar
    se <- r$Avar
    
    o$coef[j] <- b; o$se[j] <- se; o$t[j] <- b / se
    o$pval[j] <- 2 * (1 - pnorm(abs(b / se)))
    o$lo[j]   <- b - 1.96 * se
    o$hi[j]   <- b + 1.96 * se
  }
  o$sig <- cut(o$pval, c(-Inf, .01, .05, .1, Inf),
               labels = c("***", "**", "*", ""))
  o
}

########################### 5. Estimation ######################################

st_pooled <- hdcce_stages(X,             Y,            n_dim,  T_dim)
st_ct     <- hdcce_stages(X[rows_ct, ],  Y[rows_ct],   ng_ct,  T_dim)
st_nct    <- hdcce_stages(X[rows_nct, ], Y[rows_nct],  ng_nct, T_dim)

res_pooled <- despar_all(X,             Y,            n_dim,  T_dim)
res_ct     <- despar_all(X[rows_ct, ],  Y[rows_ct],   ng_ct,  T_dim)
res_nct    <- despar_all(X[rows_nct, ], Y[rows_nct],  ng_nct, T_dim)

########################### 6. Results tables ##################################

# Merge the LASSO estimate beside the desparsified one, so
# the shrinkage is visible in the output instead of buried in hdcce_inference.R.
add_lasso <- function(res, st) {
  stopifnot(identical(as.character(res$driver), names(st$beta)))
  out <- data.frame(
    driver = as.character(res$driver),
    lasso  = as.numeric(st$beta),
    kept   = ifelse(st$beta != 0, "yes", "-"),      # survived the shrinkage?
    coef   = res$coef,
    se     = res$se,
    t      = res$t,
    pval   = res$pval,
    sig    = as.character(res$sig),
    p_holm = p.adjust(res$pval, method = "holm"),   # p simultaneous tests
    lo     = res$lo,
    hi     = res$hi,
    stringsAsFactors = FALSE
  )
  attr(out, "lambda") <- st$lambda
  attr(out, "nnz")    <- st$s
  out
}

tab_pooled <- add_lasso(res_pooled, st_pooled)
tab_ct     <- add_lasso(res_ct,     st_ct)
tab_nct    <- add_lasso(res_nct,    st_nct)


tab_dir <- file.path(PROJ_DIR, "tables")
fig_dir <- file.path(PROJ_DIR, "plots")   
for (d in c(tab_dir, fig_dir)) if (!dir.exists(d)) dir.create(d, recursive = TRUE)
stopifnot(dir.exists(tab_dir), dir.exists(fig_dir))
message("tables -> ", normalizePath(tab_dir))
message("plots  -> ", normalizePath(fig_dir))

write.csv(tab_pooled, file.path(tab_dir, "desparsified_K3_pooled.csv"),        row.names = FALSE)
write.csv(tab_ct,     file.path(tab_dir, "desparsified_K3_carbon-tax.csv"),    row.names = FALSE)
write.csv(tab_nct,    file.path(tab_dir, "desparsified_K3_no-carbon-tax.csv"), row.names = FALSE)

show2 <- function(tab, tag, ng) {
  cat("\n=== ", tag, "  (n = ", ng, ", drivers = ", nrow(tab), ") ===\n", sep = "")
  cat("LASSO retained ", attr(tab, "nnz"), " of ", nrow(tab),
      " drivers at ", LAMBDA_RULE, " = ", signif(attr(tab, "lambda"), 4), "\n", sep = "")
  d <- tab[order(tab$pval),
           c("driver", "lasso", "kept", "coef", "se", "t", "pval", "sig", "p_holm")]
  d[, c("lasso", "coef", "se", "t")] <- round(d[, c("lasso", "coef", "se", "t")], 4)
  d[, c("pval", "p_holm")]           <- round(d[, c("pval", "p_holm")], 4)
  print(d, row.names = FALSE)
}

show2(tab_pooled, "pooled",        n_dim)
show2(tab_ct,     "carbon-tax",    ng_ct)
show2(tab_nct,    "no-carbon-tax", ng_nct)

########################### 7. Projection diagnostics ##########################

# Standalone objects for the pooled projection
obj          <- st_pooled$proj
Pi_hat       <- obj$Pi           # projection matrix (T x T)
K_hat        <- obj$K            # factor count used
W_hat        <- obj$W            # factor proxies (T x K)
X_bar        <- obj$X_bar        # cross-sectional averages (T x p)
eigenvalues  <- obj$eigenvalues  # normalised eigenvalues

cat("\nnormalised eigenvalues of the cross-sectional averages:\n")
print(round(cbind(pooled = st_pooled$proj$eigenvalues[1:6],
                  ctax   = st_ct$proj$eigenvalues[1:6],
                  noctax = st_nct$proj$eigenvalues[1:6]), 4))
cat("K used:", K_FACTORS,
    " | implied by the 1% rule -- pooled:", st_pooled$proj$K_suggested,
    " ctax:", st_ct$proj$K_suggested,
    " noctax:", st_nct$proj$K_suggested, "\n")
cat("median SE -- pooled:", round(median(res_pooled$se), 3),
    " ctax:", round(median(res_ct$se), 3),
    " noctax:", round(median(res_nct$se), 3),
    "  (pooled >> subsamples suggests K is too small for the pooled panel)\n")

########################### 8. Manual trace of one driver ######################

# Rebuild the desparsified estimate for one coefficient from scratch and compare
# against the package.

j  <- TRACE_J
Pi <- st_pooled$Pi
W  <- st_pooled$W
Xt <- st_pooled$xt
Yt <- st_pooled$yt
foldid <- st_pooled$foldid

cat("\nTracing driver:", driver_names[j], "\n")

## -- projector -------------------------------------------------------
cat("A1 Pi idempotent      :", isTRUE(all.equal(Pi %*% Pi, Pi)), "\n")
cat("A2 rank(Pi) == T - K  :", qr(Pi)$rank == T_dim - K_FACTORS, "\n")
cat("A3 Pi kills W         :", max(abs(Pi %*% W)) < 1e-10, "\n")

## -- defactoring -----------------------------------------------------
Xbar_t <- matrix(NA_real_, T_dim, p)
for (t in seq_len(T_dim))
  Xbar_t[t, ] <- colMeans(Xt[seq(t, n_dim * T_dim, by = T_dim), , drop = FALSE])
cat("B1 defactored CSAs orthogonal to W:", max(abs(crossprod(W, Xbar_t))) < 1e-8, "\n")
cat("B2 column sd, pre -> post projection (first 6):\n")
print(round(rbind(pre = apply(X, 2, sd), post = apply(Xt, 2, sd))[, 1:min(6, p)], 3))

## -- the shrinkage, recomputed independently -------------------------
cv_main <- cv.glmnet(Xt, Yt, foldid = foldid, alpha = 1,
                     intercept = FALSE, standardize = STANDARDIZE)
lam  <- cv_main[[LAMBDA_RULE]]
beta <- as.numeric(coef(cv_main, s = lam))[-1]
names(beta) <- driver_names

cat("C1 lambda.min / lambda.1se:", signif(c(cv_main$lambda.min, cv_main$lambda.1se), 4), "\n")
cat("C2 non-zero coefficients  :", sum(beta != 0), "of", p, "\n")
cat("C3 selected               :", paste(driver_names[beta != 0], collapse = ", "), "\n")

## -- nodewise regression for column j --------------------------------
cv_node <- cv.glmnet(Xt[, -j], Xt[, j], foldid = foldid, alpha = 1,
                     intercept = FALSE, standardize = STANDARDIZE)
gam <- as.numeric(coef(cv_node, s = cv_node[[LAMBDA_RULE]]))[-1]
z   <- as.numeric(Xt[, j] - Xt[, -j] %*% gam)

tau2 <- sum(z * Xt[, j]) / (n_dim * T_dim)
cat("D1 sd(z)                  :", signif(sd(z), 4), "\n")
cat("D2 tau^2 = z'x_j/(nT)     :", signif(tau2, 4), "\n")
cat("D3 R^2 of node regression :", signif(1 - var(z) / var(Xt[, j]), 4), "\n")
# tau^2 near zero, or D3 near 1, means driver j is still nearly a linear
# combination of the others -- the diagnostic for whether the drop list sufficed.

## -- debiasing -------------------------------------------------------
eps  <- as.numeric(Yt - Xt %*% beta)
corr <- sum(z * eps) / sum(z * Xt[, j])
b_j  <- beta[j] + corr
cat("E1 lasso beta_j     :", signif(beta[j], 5), "\n")
cat("E2 correction       :", signif(corr, 5), "\n")
cat("E3 desparsified b_j :", signif(b_j, 5), "\n")

## -- HAC standard error ----------------------------------------------
h_it  <- z * eps
Omega <- 0
for (i in seq_len(n_dim)) {
  hi    <- h_it[((i - 1) * T_dim + 1):(i * T_dim)]
  nw_i  <- sum(hi^2)
  for (l in seq_len(HAC_LAG)) {
    wgt  <- 1 - l / (HAC_LAG + 1)                      # Bartlett weight
    nw_i <- nw_i + 2 * wgt * sum(hi[(l + 1):T_dim] * hi[1:(T_dim - l)])
  }
  Omega <- Omega + nw_i
}
Omega <- Omega / (n_dim * T_dim)
se_j  <- sqrt(Omega * n_dim * T_dim) / abs(sum(z * Xt[, j]))

cat("F1 Omega (HAC)   :", signif(Omega, 5), "\n")
cat("F2 se            :", signif(se_j, 5), "\n")
cat("F3 t             :", signif(b_j / se_j, 4), "\n")
cat("F4 iid-version se:", signif(sqrt(sum(h_it^2)) / abs(sum(z * Xt[, j])), 5), "\n")

## -- compare against the package -------------------------------------
r <- hdcce_inference(data = list(x = X, y = Y), obs_N = n_dim, obs_T = T_dim,
                     foldid = foldid, COEF_INDEX_VEC = j,
                     HAC = HAC_LAG, NFACTORS = K_FACTORS)

cat("\ncoef  manual:", signif(b_j,  6), " package:", signif(r$coef_despar, 6), "\n")
cat("se    manual:", signif(se_j, 6), " package:", signif(r$Avar,        6), "\n")
cat("ratio se    :", signif(se_j / r$Avar, 4), "\n")
cat("se^2 vs Avar vs sqrt(Avar):", signif(c(se_j^2, r$Avar, sqrt(r$Avar)), 6), "\n")
cat("components returned by hdcce_inference:\n")
str(r, max.level = 1)
# If r$Avar is a VARIANCE rather than a standard error, despar_all()'s t = b/se
# and its 1.96*se intervals are wrong by a sqrt -- fix despar_all and re-run.
# If a length-p LASSO vector is returned, check it against st_pooled$beta.

########################### 9. Reduction ledger and figures ####################

reduction_ledger <- function(st) {
  pp <- st$p; K <- st$K; N <- st$obs_N; Tt <- st$obs_T   # Tt, not T
  data.frame(
    stage = c("I. Cross-sectional averaging", "II. Spectral compression",
              "III. Projection by Pi", "IV. L1 penalisation",
              "V. Desparsification"),
    acts_on = c("observations", "average columns", "time dimensions",
                "coefficients", "coefficients"),
    before  = c(N * Tt, pp, Tt, pp, st$s),
    after   = c(Tt, K, Tt - K, st$s, pp),
    discarded = c(sprintf("%d unit-level deviations per date", N - 1),
                  sprintf("%d trailing principal directions", pp - K),
                  sprintf("%d time dimensions per unit", K),
                  sprintf("%d coefficients set to zero", pp - st$s),
                  "nothing"),
    kept = c("common component only",
             sprintf("%.1f%% of average variance",
                     100 * sum(st$evn[1:K]) / sum(st$evn)),
             sprintf("%d usable periods", Tt - K),
             sprintf("%d non-zero at lambda=%.4g", st$s, st$lambda),
             sprintf("all %d get a CI", pp)),
    direction = c(rep("discard", 4), "restore"),
    stringsAsFactors = FALSE
  )
}

plot_reductions <- function(st, res = NULL, file = "reduction_figures.pdf") {
  pdf(file, width = 9, height = 6.2)
  on.exit(dev.off())
  op <- par(mar = c(4.6, 4.6, 3.2, 1.4), cex.main = 1.15, font.main = 1)
  on.exit(par(op), add = TRUE)
  pp <- st$p; K <- st$K; Tt <- st$obs_T
  
  ## FIG 1 -- the degrees-of-freedom budget
  spent <- c("Classical CCE" = pp + 1, "HD-CCE" = K)
  m  <- rbind(spent = spent, left = Tt - spent)
  bp <- barplot(m, horiz = TRUE, col = c("grey35", "grey85"), border = NA,
                xlim = c(0, Tt), xlab = "time periods", las = 1,
                main = sprintf("Reduction II: nuisance budget out of T = %d", Tt))
  text(spent / 2, bp, spent, col = "white", font = 2)
  text(spent + (Tt - spent) / 2, bp, Tt - spent, col = "grey20", font = 2)
  legend("topright", c("spent on nuisance terms", "left for estimation"),
         fill = c("grey35", "grey85"), border = NA, bty = "n")
  
  ## FIG 2 -- the eigenvalue spectrum
  k    <- min(12, pp)
  cols <- ifelse(seq_len(k) <= K, "grey25", "grey80")
  bp <- barplot(st$evn[1:k], col = cols, border = NA, names.arg = seq_len(k),
                xlab = "principal direction of the cross-sectional averages",
                ylab = expression(lambda[k] / lambda[1]),
                main = sprintf("Reduction II: %d of %d directions retained", K, pp))
  abline(v = (bp[K] + bp[K + 1]) / 2, lty = 2)
  text((bp[K] + bp[K + 1]) / 2, max(st$evn) * .8, "  discarded", adj = 0, cex = .9)
  
  ## FIG 3 -- what the projection costs each driver
  o <- order(st$var_kept)
  par(mar = c(4.6, 13, 3.2, 1.4))
  barplot(st$var_kept[o], horiz = TRUE, las = 1, border = NA, col = "grey45",
          names.arg = st$driver[o], cex.names = .62, xlim = c(0, 1),
          xlab = "share of variance surviving the projection",
          main = "Reduction III: variance removed by factor projection")
  abline(v = (Tt - K) / Tt, lty = 2)
  par(mar = c(4.6, 4.6, 3.2, 1.4))
  
  ## FIG 4 -- selection as a function of the penalty
  gf <- st$cv$glmnet.fit
  if (!is.null(gf) && !is.null(gf$df)) {
    plot(log(gf$lambda), gf$df, type = "s", lwd = 2, col = "grey25",
         xlab = expression(log(lambda)), ylab = "non-zero coefficients",
         main = "Reduction IV: how many drivers survive the penalty")
    abline(v = log(st$lambda), lty = 2)
    abline(h = st$s, lty = 3, col = "grey60")
    text(log(st$lambda), max(gf$df) * .95,
         sprintf(" selected: %d of %d", st$s, pp), adj = 0, cex = .9)
  }
  
  ## FIG 5 -- the undiscarding
  if (!is.null(res)) {
    stopifnot(all(c("driver", "coef", "lo", "hi") %in% names(res)))
    idx <- match(st$driver, as.character(res$driver))
    b_l <- st$beta
    b_d <- res$coef[idx]; lo <- res$lo[idx]; hi <- res$hi[idx]
    o   <- order(b_d)
    yy  <- seq_along(o)
    
    # Clip to a robust window; one very wide interval would flatten the rest.
    pad  <- median(hi - lo, na.rm = TRUE)
    xlim <- c(min(c(b_d, b_l), na.rm = TRUE) - pad,
              max(c(b_d, b_l), na.rm = TRUE) + pad)
    lo_c <- pmax(lo[o], xlim[1]); hi_c <- pmin(hi[o], xlim[2])
    cut_l <- lo[o] < xlim[1];     cut_h <- hi[o] > xlim[2]
    
    par(mar = c(4.6, 13, 3.2, 1.4))
    plot(NA, xlim = xlim, ylim = c(.5, pp + .5), yaxt = "n", ylab = "",
         xlab = "coefficient",
         main = "Reduction IV undone: LASSO estimate -> desparsified estimate")
    axis(2, at = yy, labels = st$driver[o], las = 1, cex.axis = .62, tick = FALSE)
    abline(v = 0, col = "grey70")
    segments(lo_c, yy, hi_c, yy, col = "grey75", lwd = 2)
    if (any(cut_l)) arrows(lo_c[cut_l] + diff(xlim) * .02, yy[cut_l],
                           lo_c[cut_l], yy[cut_l], length = .045,
                           col = "grey75", lwd = 2)
    if (any(cut_h)) arrows(hi_c[cut_h] - diff(xlim) * .02, yy[cut_h],
                           hi_c[cut_h], yy[cut_h], length = .045,
                           col = "grey75", lwd = 2)
    arrows(b_l[o], yy, b_d[o], yy, length = .05, col = "grey45")
    points(b_l[o], yy, pch = ifelse(b_l[o] == 0, 4, 19), col = "grey30", cex = .7)
    points(b_d[o], yy, pch = 21, bg = "white", col = "black", cex = .85)
    legend("bottomright", c("LASSO (x = shrunk to zero)", "desparsified, 95% CI"),
           pch = c(4, 21), pt.bg = "white", bty = "n", cex = .8)
    par(mar = c(4.6, 4.6, 3.2, 1.4))
  }
  invisible(NULL)
}

led_pooled <- reduction_ledger(st_pooled)
led_ct     <- reduction_ledger(st_ct)
led_nct    <- reduction_ledger(st_nct)

cat("\n")
print(led_pooled[, c("stage", "acts_on", "before", "after", "discarded")],
      row.names = FALSE)

write.csv(led_pooled, file.path(tab_dir, "reduction_ledger_pooled.csv"),        row.names = FALSE)
write.csv(led_ct,     file.path(tab_dir, "reduction_ledger_carbon-tax.csv"),    row.names = FALSE)
write.csv(led_nct,    file.path(tab_dir, "reduction_ledger_no-carbon-tax.csv"), row.names = FALSE)

plot_reductions(st_pooled, res_pooled, file.path(fig_dir, "reductions_pooled.pdf"))
plot_reductions(st_ct,     res_ct,     file.path(fig_dir, "reductions_carbon-tax.pdf"))
plot_reductions(st_nct,    res_nct,    file.path(fig_dir, "reductions_no-carbon-tax.pdf"))

# Latex version
cat("\n\\begin{tabular}{@{}llrrl@{}}\n\\toprule\n",
    "Stage & Acts on & Before & After & Discarded \\\\\n\\midrule\n", sep = "")
for (i in seq_len(nrow(led_pooled)))
  cat(sprintf("%s & %s & %d & %d & %s \\\\\n",
              led_pooled$stage[i], led_pooled$acts_on[i],
              led_pooled$before[i], led_pooled$after[i],
              gsub("%", "\\\\%", led_pooled$discarded[i])))
cat("\\bottomrule\n\\end{tabular}\n")

########################### 10. Consistency checks #############################

# check if standardize or lambda rule agree
cat("\n--- consistency ---\n")
cat("manual trace beta == pipeline beta:",
    isTRUE(all.equal(unname(beta), unname(st_pooled$beta))), "\n")
cat("results table lasso == pipeline beta:",
    isTRUE(all.equal(tab_pooled$lasso, unname(st_pooled$beta))), "\n")
cat("driver order aligned across tables:",
    identical(tab_pooled$driver, tab_ct$driver) &&
      identical(tab_pooled$driver, tab_nct$driver), "\n")
